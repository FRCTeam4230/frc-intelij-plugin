// Generated from com\asarkar\semver\antlr\SemVer.g4 by ANTLR 4.8

package com.asarkar.semver.antlr;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class SemVerParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		ZERO=1, HYPHEN=2, DOT=3, PLUS=4, POSITIVE_DIGIT=5, LETTER=6;
	public static final int
		RULE_semVer = 0, RULE_normalVersion = 1, RULE_majorVersion = 2, RULE_minorVersion = 3, 
		RULE_patchVersion = 4, RULE_preReleaseVersion = 5, RULE_buildMetadata = 6, 
		RULE_preReleaseId = 7, RULE_buildMetadataId = 8, RULE_alphanumericId = 9, 
		RULE_numericId = 10, RULE_characters = 11, RULE_character = 12, RULE_digits = 13, 
		RULE_nonDigit = 14, RULE_digit = 15;
	private static String[] makeRuleNames() {
		return new String[] {
			"semVer", "normalVersion", "majorVersion", "minorVersion", "patchVersion", 
			"preReleaseVersion", "buildMetadata", "preReleaseId", "buildMetadataId", 
			"alphanumericId", "numericId", "characters", "character", "digits", "nonDigit", 
			"digit"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'0'", "'-'", "'.'", "'+'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "ZERO", "HYPHEN", "DOT", "PLUS", "POSITIVE_DIGIT", "LETTER"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "SemVer.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public SemVerParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class SemVerContext extends ParserRuleContext {
		public NormalVersionContext normalVersion() {
			return getRuleContext(NormalVersionContext.class,0);
		}
		public TerminalNode HYPHEN() { return getToken(SemVerParser.HYPHEN, 0); }
		public PreReleaseVersionContext preReleaseVersion() {
			return getRuleContext(PreReleaseVersionContext.class,0);
		}
		public TerminalNode PLUS() { return getToken(SemVerParser.PLUS, 0); }
		public BuildMetadataContext buildMetadata() {
			return getRuleContext(BuildMetadataContext.class,0);
		}
		public SemVerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_semVer; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitSemVer(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SemVerContext semVer() throws RecognitionException {
		SemVerContext _localctx = new SemVerContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_semVer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(32);
			normalVersion();
			setState(35);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HYPHEN) {
				{
				setState(33);
				match(HYPHEN);
				setState(34);
				preReleaseVersion();
				}
			}

			setState(39);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==PLUS) {
				{
				setState(37);
				match(PLUS);
				setState(38);
				buildMetadata();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NormalVersionContext extends ParserRuleContext {
		public MajorVersionContext majorVersion() {
			return getRuleContext(MajorVersionContext.class,0);
		}
		public List<TerminalNode> DOT() { return getTokens(SemVerParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(SemVerParser.DOT, i);
		}
		public MinorVersionContext minorVersion() {
			return getRuleContext(MinorVersionContext.class,0);
		}
		public PatchVersionContext patchVersion() {
			return getRuleContext(PatchVersionContext.class,0);
		}
		public NormalVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_normalVersion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitNormalVersion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NormalVersionContext normalVersion() throws RecognitionException {
		NormalVersionContext _localctx = new NormalVersionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_normalVersion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(41);
			majorVersion();
			setState(42);
			match(DOT);
			setState(43);
			minorVersion();
			setState(44);
			match(DOT);
			setState(45);
			patchVersion();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MajorVersionContext extends ParserRuleContext {
		public NumericIdContext numericId() {
			return getRuleContext(NumericIdContext.class,0);
		}
		public MajorVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_majorVersion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitMajorVersion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MajorVersionContext majorVersion() throws RecognitionException {
		MajorVersionContext _localctx = new MajorVersionContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_majorVersion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			numericId();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MinorVersionContext extends ParserRuleContext {
		public NumericIdContext numericId() {
			return getRuleContext(NumericIdContext.class,0);
		}
		public MinorVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_minorVersion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitMinorVersion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MinorVersionContext minorVersion() throws RecognitionException {
		MinorVersionContext _localctx = new MinorVersionContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_minorVersion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(49);
			numericId();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PatchVersionContext extends ParserRuleContext {
		public NumericIdContext numericId() {
			return getRuleContext(NumericIdContext.class,0);
		}
		public PatchVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_patchVersion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitPatchVersion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PatchVersionContext patchVersion() throws RecognitionException {
		PatchVersionContext _localctx = new PatchVersionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_patchVersion);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(51);
			numericId();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PreReleaseVersionContext extends ParserRuleContext {
		public List<PreReleaseIdContext> preReleaseId() {
			return getRuleContexts(PreReleaseIdContext.class);
		}
		public PreReleaseIdContext preReleaseId(int i) {
			return getRuleContext(PreReleaseIdContext.class,i);
		}
		public List<TerminalNode> DOT() { return getTokens(SemVerParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(SemVerParser.DOT, i);
		}
		public PreReleaseVersionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_preReleaseVersion; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitPreReleaseVersion(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PreReleaseVersionContext preReleaseVersion() throws RecognitionException {
		PreReleaseVersionContext _localctx = new PreReleaseVersionContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_preReleaseVersion);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(53);
			preReleaseId();
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DOT) {
				{
				{
				setState(54);
				match(DOT);
				setState(55);
				preReleaseId();
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BuildMetadataContext extends ParserRuleContext {
		public List<BuildMetadataIdContext> buildMetadataId() {
			return getRuleContexts(BuildMetadataIdContext.class);
		}
		public BuildMetadataIdContext buildMetadataId(int i) {
			return getRuleContext(BuildMetadataIdContext.class,i);
		}
		public List<TerminalNode> DOT() { return getTokens(SemVerParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(SemVerParser.DOT, i);
		}
		public BuildMetadataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_buildMetadata; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitBuildMetadata(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BuildMetadataContext buildMetadata() throws RecognitionException {
		BuildMetadataContext _localctx = new BuildMetadataContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_buildMetadata);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(61);
			buildMetadataId();
			setState(66);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DOT) {
				{
				{
				setState(62);
				match(DOT);
				setState(63);
				buildMetadataId();
				}
				}
				setState(68);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PreReleaseIdContext extends ParserRuleContext {
		public AlphanumericIdContext alphanumericId() {
			return getRuleContext(AlphanumericIdContext.class,0);
		}
		public NumericIdContext numericId() {
			return getRuleContext(NumericIdContext.class,0);
		}
		public PreReleaseIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_preReleaseId; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitPreReleaseId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PreReleaseIdContext preReleaseId() throws RecognitionException {
		PreReleaseIdContext _localctx = new PreReleaseIdContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_preReleaseId);
		try {
			setState(71);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(69);
				alphanumericId();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(70);
				numericId();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BuildMetadataIdContext extends ParserRuleContext {
		public AlphanumericIdContext alphanumericId() {
			return getRuleContext(AlphanumericIdContext.class,0);
		}
		public DigitsContext digits() {
			return getRuleContext(DigitsContext.class,0);
		}
		public BuildMetadataIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_buildMetadataId; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitBuildMetadataId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BuildMetadataIdContext buildMetadataId() throws RecognitionException {
		BuildMetadataIdContext _localctx = new BuildMetadataIdContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_buildMetadataId);
		try {
			setState(75);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(73);
				alphanumericId();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(74);
				digits();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AlphanumericIdContext extends ParserRuleContext {
		public NonDigitContext nonDigit() {
			return getRuleContext(NonDigitContext.class,0);
		}
		public List<CharactersContext> characters() {
			return getRuleContexts(CharactersContext.class);
		}
		public CharactersContext characters(int i) {
			return getRuleContext(CharactersContext.class,i);
		}
		public AlphanumericIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_alphanumericId; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitAlphanumericId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AlphanumericIdContext alphanumericId() throws RecognitionException {
		AlphanumericIdContext _localctx = new AlphanumericIdContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_alphanumericId);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(78);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				setState(77);
				characters();
				}
				break;
			}
			setState(80);
			nonDigit();
			setState(82);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << ZERO) | (1L << HYPHEN) | (1L << POSITIVE_DIGIT) | (1L << LETTER))) != 0)) {
				{
				setState(81);
				characters();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumericIdContext extends ParserRuleContext {
		public TerminalNode ZERO() { return getToken(SemVerParser.ZERO, 0); }
		public TerminalNode POSITIVE_DIGIT() { return getToken(SemVerParser.POSITIVE_DIGIT, 0); }
		public DigitsContext digits() {
			return getRuleContext(DigitsContext.class,0);
		}
		public NumericIdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numericId; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitNumericId(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumericIdContext numericId() throws RecognitionException {
		NumericIdContext _localctx = new NumericIdContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_numericId);
		int _la;
		try {
			setState(89);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ZERO:
				enterOuterAlt(_localctx, 1);
				{
				setState(84);
				match(ZERO);
				}
				break;
			case POSITIVE_DIGIT:
				enterOuterAlt(_localctx, 2);
				{
				setState(85);
				match(POSITIVE_DIGIT);
				setState(87);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ZERO || _la==POSITIVE_DIGIT) {
					{
					setState(86);
					digits();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharactersContext extends ParserRuleContext {
		public List<CharacterContext> character() {
			return getRuleContexts(CharacterContext.class);
		}
		public CharacterContext character(int i) {
			return getRuleContext(CharacterContext.class,i);
		}
		public CharactersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_characters; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitCharacters(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharactersContext characters() throws RecognitionException {
		CharactersContext _localctx = new CharactersContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_characters);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(92); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(91);
					character();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(94); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,10,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharacterContext extends ParserRuleContext {
		public DigitContext digit() {
			return getRuleContext(DigitContext.class,0);
		}
		public NonDigitContext nonDigit() {
			return getRuleContext(NonDigitContext.class,0);
		}
		public CharacterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_character; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitCharacter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharacterContext character() throws RecognitionException {
		CharacterContext _localctx = new CharacterContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_character);
		try {
			setState(98);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ZERO:
			case POSITIVE_DIGIT:
				enterOuterAlt(_localctx, 1);
				{
				setState(96);
				digit();
				}
				break;
			case HYPHEN:
			case LETTER:
				enterOuterAlt(_localctx, 2);
				{
				setState(97);
				nonDigit();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DigitsContext extends ParserRuleContext {
		public List<DigitContext> digit() {
			return getRuleContexts(DigitContext.class);
		}
		public DigitContext digit(int i) {
			return getRuleContext(DigitContext.class,i);
		}
		public DigitsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_digits; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitDigits(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DigitsContext digits() throws RecognitionException {
		DigitsContext _localctx = new DigitsContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_digits);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(101); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(100);
				digit();
				}
				}
				setState(103); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==ZERO || _la==POSITIVE_DIGIT );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NonDigitContext extends ParserRuleContext {
		public TerminalNode LETTER() { return getToken(SemVerParser.LETTER, 0); }
		public TerminalNode HYPHEN() { return getToken(SemVerParser.HYPHEN, 0); }
		public NonDigitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nonDigit; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitNonDigit(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NonDigitContext nonDigit() throws RecognitionException {
		NonDigitContext _localctx = new NonDigitContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_nonDigit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(105);
			_la = _input.LA(1);
			if ( !(_la==HYPHEN || _la==LETTER) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DigitContext extends ParserRuleContext {
		public TerminalNode ZERO() { return getToken(SemVerParser.ZERO, 0); }
		public TerminalNode POSITIVE_DIGIT() { return getToken(SemVerParser.POSITIVE_DIGIT, 0); }
		public DigitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_digit; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SemVerVisitor ) return ((SemVerVisitor<? extends T>)visitor).visitDigit(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DigitContext digit() throws RecognitionException {
		DigitContext _localctx = new DigitContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_digit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(107);
			_la = _input.LA(1);
			if ( !(_la==ZERO || _la==POSITIVE_DIGIT) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\bp\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4"+
		"\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\3\2\3\2\3\2\5\2"+
		"&\n\2\3\2\3\2\5\2*\n\2\3\3\3\3\3\3\3\3\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6"+
		"\3\7\3\7\3\7\7\7;\n\7\f\7\16\7>\13\7\3\b\3\b\3\b\7\bC\n\b\f\b\16\bF\13"+
		"\b\3\t\3\t\5\tJ\n\t\3\n\3\n\5\nN\n\n\3\13\5\13Q\n\13\3\13\3\13\5\13U\n"+
		"\13\3\f\3\f\3\f\5\fZ\n\f\5\f\\\n\f\3\r\6\r_\n\r\r\r\16\r`\3\16\3\16\5"+
		"\16e\n\16\3\17\6\17h\n\17\r\17\16\17i\3\20\3\20\3\21\3\21\3\21\2\2\22"+
		"\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \2\4\4\2\4\4\b\b\4\2\3\3\7\7\2"+
		"l\2\"\3\2\2\2\4+\3\2\2\2\6\61\3\2\2\2\b\63\3\2\2\2\n\65\3\2\2\2\f\67\3"+
		"\2\2\2\16?\3\2\2\2\20I\3\2\2\2\22M\3\2\2\2\24P\3\2\2\2\26[\3\2\2\2\30"+
		"^\3\2\2\2\32d\3\2\2\2\34g\3\2\2\2\36k\3\2\2\2 m\3\2\2\2\"%\5\4\3\2#$\7"+
		"\4\2\2$&\5\f\7\2%#\3\2\2\2%&\3\2\2\2&)\3\2\2\2\'(\7\6\2\2(*\5\16\b\2)"+
		"\'\3\2\2\2)*\3\2\2\2*\3\3\2\2\2+,\5\6\4\2,-\7\5\2\2-.\5\b\5\2./\7\5\2"+
		"\2/\60\5\n\6\2\60\5\3\2\2\2\61\62\5\26\f\2\62\7\3\2\2\2\63\64\5\26\f\2"+
		"\64\t\3\2\2\2\65\66\5\26\f\2\66\13\3\2\2\2\67<\5\20\t\289\7\5\2\29;\5"+
		"\20\t\2:8\3\2\2\2;>\3\2\2\2<:\3\2\2\2<=\3\2\2\2=\r\3\2\2\2><\3\2\2\2?"+
		"D\5\22\n\2@A\7\5\2\2AC\5\22\n\2B@\3\2\2\2CF\3\2\2\2DB\3\2\2\2DE\3\2\2"+
		"\2E\17\3\2\2\2FD\3\2\2\2GJ\5\24\13\2HJ\5\26\f\2IG\3\2\2\2IH\3\2\2\2J\21"+
		"\3\2\2\2KN\5\24\13\2LN\5\34\17\2MK\3\2\2\2ML\3\2\2\2N\23\3\2\2\2OQ\5\30"+
		"\r\2PO\3\2\2\2PQ\3\2\2\2QR\3\2\2\2RT\5\36\20\2SU\5\30\r\2TS\3\2\2\2TU"+
		"\3\2\2\2U\25\3\2\2\2V\\\7\3\2\2WY\7\7\2\2XZ\5\34\17\2YX\3\2\2\2YZ\3\2"+
		"\2\2Z\\\3\2\2\2[V\3\2\2\2[W\3\2\2\2\\\27\3\2\2\2]_\5\32\16\2^]\3\2\2\2"+
		"_`\3\2\2\2`^\3\2\2\2`a\3\2\2\2a\31\3\2\2\2be\5 \21\2ce\5\36\20\2db\3\2"+
		"\2\2dc\3\2\2\2e\33\3\2\2\2fh\5 \21\2gf\3\2\2\2hi\3\2\2\2ig\3\2\2\2ij\3"+
		"\2\2\2j\35\3\2\2\2kl\t\2\2\2l\37\3\2\2\2mn\t\3\2\2n!\3\2\2\2\17%)<DIM"+
		"PTY[`di";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}