// Generated from com\asarkar\semver\antlr\SemVer.g4 by ANTLR 4.9.3

package com.asarkar.semver.antlr;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SemVerParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SemVerVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SemVerParser#semVer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSemVer(SemVerParser.SemVerContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#normalVersion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNormalVersion(SemVerParser.NormalVersionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#majorVersion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMajorVersion(SemVerParser.MajorVersionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#minorVersion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMinorVersion(SemVerParser.MinorVersionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#patchVersion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPatchVersion(SemVerParser.PatchVersionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#preReleaseVersion}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPreReleaseVersion(SemVerParser.PreReleaseVersionContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#buildMetadata}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBuildMetadata(SemVerParser.BuildMetadataContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#preReleaseId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPreReleaseId(SemVerParser.PreReleaseIdContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#buildMetadataId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBuildMetadataId(SemVerParser.BuildMetadataIdContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#alphanumericId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAlphanumericId(SemVerParser.AlphanumericIdContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#numericId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericId(SemVerParser.NumericIdContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#characters}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharacters(SemVerParser.CharactersContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#character}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharacter(SemVerParser.CharacterContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#digits}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDigits(SemVerParser.DigitsContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#nonDigit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNonDigit(SemVerParser.NonDigitContext ctx);
	/**
	 * Visit a parse tree produced by {@link SemVerParser#digit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDigit(SemVerParser.DigitContext ctx);
}